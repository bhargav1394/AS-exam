#!/usr/bin/python

def divisors(input_list):
    nr_divisors = []
    for i in input_list:
        my_list = []
        for x in range(1, i+1):
            if i % x == 0:
                my_list.append(x)
        nr_divisors.append(len(my_list))
    return input_list[nr_divisors.index(max(nr_divisors))]

a = [8, 12, 18, 6]

print divisors(a)
