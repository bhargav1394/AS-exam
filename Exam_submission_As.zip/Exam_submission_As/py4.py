#!/usr/bin/python
import time
import webbrowser
import tkMessageBox



while True: 
	
	time.sleep(15)

	tkMessageBox.showinfo(title="BreakTime", message="EnjoyTime")
	print"time to break"
	webbrowser.open("http://www.youtube.com/watch?v=YXw16RzMofo")
